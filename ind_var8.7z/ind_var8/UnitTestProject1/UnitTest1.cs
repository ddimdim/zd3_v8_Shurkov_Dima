﻿using indiv_8;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.ConstrainedExecution;
using System.Runtime.Remoting.Lifetime;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            int mileage = 78421;
            double rashod = 21.7;
            string brand = "BMW";
            string model = "m5";
            var car = new Car(mileage, rashod, brand, model);
            double actual = car.Quality();
            double expected = mileage / rashod;
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void TestMethod2()
        {
            int mileage = 78421;
            double rashod = 21.7;
            string brand = "BMW";
            string model = "m5";
            var car = new Car(mileage, rashod, brand, model);
            string actual = car.ToString();
            string expected = $"{brand} {model}; Пробег:{mileage}, расход на км {rashod}, Q = {car.Quality()}";
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestMethod3()
        {
            int mileage = 78421;
            double rashod = 21.7;
            string brand = "BMW";
            string model = "m5";
            int year = 2011;
            double price = 25000000;
            var sportcar = new SportCar(mileage, rashod, brand, model, year, price);
            double actual = sportcar.Qp();
            double expected = sportcar.Quality() * 1.15 * year;
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void TestMethod4()
        {
            int mileage = 78421;
            double rashod = 21.7;
            string brand = "BMW";
            string model = "m5";
            int year = 2011;
            double price = 25000000;
            var sportcar = new SportCar(mileage, rashod, brand, model, year, price);
            string actual = sportcar.ToString();
            string expected = $"{brand} {model}; Пробег:{mileage}, расход на км {rashod}, Q = {sportcar.Quality()} Qp = {sportcar.Qp()}, Год выпуска: {year}, Цена: {price}";
            Assert.AreEqual(expected, actual);
        }
    }
}
