﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace indiv_8
{
    public class SportCar : Car
    {
        public int Year { get; set; }
        public double Price { get; set; }
        public SportCar (int mileage, double rashod, string brand, string model, int year, double price) : base(mileage, rashod, brand, model)
        {
            Year = year;
            Price = price;
        }
        public double Qp ()
        {
            return Quality() * 1.15 * Year;
        }
        public override string ToString ()
        {
            return base.ToString() + $" Qp = {Qp()}, Год выпуска: {Year}, Цена: {Price}";
        }
    }
}
