﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace indiv_8
{
    public class Car
    {
        public int Mileage { get; set; }
        public double Rashod { get; set; }
        public string Brand { get; set; }
        public string Model { get; set; }
        public Car (int mileage, double rashod, string brand, string model)
        {
            Mileage = mileage;
            Rashod = rashod;
            Brand = brand;
            Model = model;
        }
        public double Quality ()
        {
            return Mileage / Rashod;
        }

        public override string ToString ()
        {
            return $"{Brand} {Model}; Пробег:{Mileage}, расход на км {Rashod}, Q = {Quality()}";
        }


    }
}
