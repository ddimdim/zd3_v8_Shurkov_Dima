﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace indiv_8
{
    public partial class Form1 :Form
    {
        
        List<Car> cars = new List<Car>();
        Queue<SportCar> sportcars = new Queue<SportCar>();
        public Form1 ()
        {
            InitializeComponent();
        }

        private void AddCarButton_Click (object sender, EventArgs e)
        {
            try
            {
                if (BrandTextBox.Text == "" || ModelTextBox.Text == "" || MileageTextBox.Text == "" || RashodTextBox.Text == "")
                {
                    MessageBox.Show("Введите все необходимые данные", "Ошибка");
                }
                else if (Letters(BrandTextBox.Text) == false)
                {
                    MessageBox.Show("При вводе брэнда можно использовать только английские буквы", "Ошибка");
                }
                else if (Numbers(RashodTextBox.Text) == false || Numbers(MileageTextBox.Text) == false)
                {
                    MessageBox.Show("При вводе пробега и расхода можно использовать только числа", "Ошибка");
                }
                else
                {
                    string brand = BrandTextBox.Text;
                    string model = ModelTextBox.Text;
                    int mileage = int.Parse(MileageTextBox.Text);
                    double rashod = double.Parse(RashodTextBox.Text);
                    Car car = new Car(mileage, rashod, brand, model);
                    AddCar(car);
                    UpdateCars();
                }
            }
            catch
            {
                MessageBox.Show("Неверно введены данные", "Ошибка");
            }
            

        }
        //2 перегрузки
        private void AddCar (Car car)
        {
            cars.Add(car);
            UpdateCars();
        }
        private void AddCar (SportCar SportCar)
        {
            sportcars.Enqueue(SportCar);
            UpdateSportCars();
        }
        private void RemoveCar (ListBox listBox, int index)
        {
            cars.RemoveAt(index);
            UpdateCars();
        }
        private void RemoveCar (int index)
        {
            for (int i = 0; i < sportcars.Count; i++)
            {
                var check = sportcars.Dequeue();

                if (i != index)
                {
                    sportcars.Enqueue(check);
                }
            }
            UpdateSportCars();
        }
        //Проверки с помощью методов LINQ
        public bool Letters (string word)
        {
            string check = new string(word.Where(w => (w >= 'a' && w <= 'z') || (w >= 'A' && w <= 'Z')).ToArray());
            if (check.Length == word.Length)
                return true;
            else return false;
            
        }
        public bool Numbers (string num)
        {
            string check = new string(num.Where(n => !Char.IsLetter(n)).ToArray());
            if (check.Length == num.Length)
                return true;
            else
                return false;

        }
        private void UpdateCars ()
        {
            CarslistBox.Items.Clear();
            foreach (Car car in cars)
            {
                CarslistBox.Items.Add(car.ToString());
            }
        }
        private void UpdateSportCars()
        {
            SportCarslistBox.Items.Clear();
            foreach (SportCar sportcar in sportcars)
            {
                SportCarslistBox.Items.Add(sportcar.ToString());
            }
        }

        private void RemoveCarButton_Click (object sender, EventArgs e)
        {
            int index = CarslistBox.SelectedIndex;
            if (index >= 0)
            {
                RemoveCar(CarslistBox, index);
                UpdateCars();
            } else
                MessageBox.Show("Выберите строку, которую хотите удалить", "Ошибка");
        }

        private void AddSportCarButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (BrandTextBox.Text == "" || ModelTextBox.Text == "" || MileageTextBox.Text == "" || RashodTextBox.Text == "" || YearTextBox.Text == "" || PriceTextBox.Text == "")
                {
                    MessageBox.Show("Введите все необходимые данные", "Ошибка");
                }
                else if (Letters(BrandTextBox.Text) == false)
                {
                    MessageBox.Show("При вводе брэнда можно использовать только английские буквы", "Ошибка");
                }
                else if (Numbers(RashodTextBox.Text) == false || Numbers(MileageTextBox.Text) == false || Numbers(YearTextBox.Text) == false || Numbers(PriceTextBox.Text) == false)
                {
                    MessageBox.Show("При вводе пробега, года выпуска, цены и расхода можно использовать только числа", "Ошибка");
                }
                else if (int.Parse(YearTextBox.Text) > 2023 || int.Parse(YearTextBox.Text) < 1938)
                {
                    MessageBox.Show("Введите год выпуска корректно", "Ошибка");
                }
                else
                {
                    string brand = BrandTextBox.Text;
                    string model = ModelTextBox.Text;
                    int mileage = int.Parse(MileageTextBox.Text);
                    double rashod = double.Parse(RashodTextBox.Text);
                    int year = int.Parse(YearTextBox.Text);
                    double price = double.Parse(PriceTextBox.Text);
                    SportCar sportcar = new SportCar(mileage, rashod, brand, model, year, price);
                    AddCar(sportcar);
                    UpdateSportCars();
                }
            }
            catch
            {
                MessageBox.Show("Неверно введены данные", "Ошибка");
            }
            
        }

        private void RemoveSportCarButton_Click(object sender, EventArgs e)
        {
            int index = SportCarslistBox.SelectedIndex;
            if (index >= 0)
            {
                RemoveCar(index);
                UpdateSportCars();
            }
            else
                MessageBox.Show("Выберите строку, которую хотите удалить", "Ошибка");
        }
    }
}
