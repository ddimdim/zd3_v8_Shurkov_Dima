﻿
namespace indiv_8
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose (bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent ()
        {
            this.CarslistBox = new System.Windows.Forms.ListBox();
            this.RashodTextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.MileageTextBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.ModelTextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.BrandTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.PriceTextBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.YearTextBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.AddCarButton = new System.Windows.Forms.Button();
            this.AddSportCarButton = new System.Windows.Forms.Button();
            this.SportCarslistBox = new System.Windows.Forms.ListBox();
            this.RemoveCarButton = new System.Windows.Forms.Button();
            this.RemoveSportCarButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // CarslistBox
            // 
            this.CarslistBox.FormattingEnabled = true;
            this.CarslistBox.Location = new System.Drawing.Point(432, 94);
            this.CarslistBox.Name = "CarslistBox";
            this.CarslistBox.Size = new System.Drawing.Size(716, 199);
            this.CarslistBox.TabIndex = 8;
            // 
            // RashodTextBox
            // 
            this.RashodTextBox.Location = new System.Drawing.Point(48, 249);
            this.RashodTextBox.Name = "RashodTextBox";
            this.RashodTextBox.Size = new System.Drawing.Size(136, 20);
            this.RashodTextBox.TabIndex = 16;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(45, 233);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 13);
            this.label4.TabIndex = 15;
            this.label4.Text = "Расход на км";
            // 
            // MileageTextBox
            // 
            this.MileageTextBox.Location = new System.Drawing.Point(48, 190);
            this.MileageTextBox.Name = "MileageTextBox";
            this.MileageTextBox.Size = new System.Drawing.Size(136, 20);
            this.MileageTextBox.TabIndex = 14;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(45, 174);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 13);
            this.label3.TabIndex = 13;
            this.label3.Text = "Пробег";
            // 
            // ModelTextBox
            // 
            this.ModelTextBox.Location = new System.Drawing.Point(48, 136);
            this.ModelTextBox.Name = "ModelTextBox";
            this.ModelTextBox.Size = new System.Drawing.Size(136, 20);
            this.ModelTextBox.TabIndex = 12;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(45, 120);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "Модель";
            // 
            // BrandTextBox
            // 
            this.BrandTextBox.Location = new System.Drawing.Point(48, 85);
            this.BrandTextBox.Name = "BrandTextBox";
            this.BrandTextBox.Size = new System.Drawing.Size(136, 20);
            this.BrandTextBox.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(45, 69);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Брэнд";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.ForeColor = System.Drawing.Color.Gray;
            this.label5.Location = new System.Drawing.Point(34, 35);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(172, 24);
            this.label5.TabIndex = 17;
            this.label5.Text = "Для простых авто";
            // 
            // PriceTextBox
            // 
            this.PriceTextBox.Location = new System.Drawing.Point(266, 145);
            this.PriceTextBox.Name = "PriceTextBox";
            this.PriceTextBox.Size = new System.Drawing.Size(136, 20);
            this.PriceTextBox.TabIndex = 21;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(263, 129);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(33, 13);
            this.label6.TabIndex = 20;
            this.label6.Text = "Цена";
            // 
            // YearTextBox
            // 
            this.YearTextBox.Location = new System.Drawing.Point(266, 94);
            this.YearTextBox.Name = "YearTextBox";
            this.YearTextBox.Size = new System.Drawing.Size(136, 20);
            this.YearTextBox.TabIndex = 19;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(263, 78);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(71, 13);
            this.label7.TabIndex = 18;
            this.label7.Text = "Год выпуска";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.ForeColor = System.Drawing.Color.Gray;
            this.label8.Location = new System.Drawing.Point(244, 35);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(205, 24);
            this.label8.TabIndex = 22;
            this.label8.Text = "Для спортивных авто";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.Gray;
            this.label9.Location = new System.Drawing.Point(291, 59);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(91, 13);
            this.label9.TabIndex = 23;
            this.label9.Text = "(Ввести 6 полей)";
            // 
            // AddCarButton
            // 
            this.AddCarButton.Location = new System.Drawing.Point(43, 292);
            this.AddCarButton.Name = "AddCarButton";
            this.AddCarButton.Size = new System.Drawing.Size(141, 28);
            this.AddCarButton.TabIndex = 24;
            this.AddCarButton.Text = "Добавить простое авто";
            this.AddCarButton.UseVisualStyleBackColor = true;
            this.AddCarButton.Click += new System.EventHandler(this.AddCarButton_Click);
            // 
            // AddSportCarButton
            // 
            this.AddSportCarButton.Location = new System.Drawing.Point(257, 190);
            this.AddSportCarButton.Name = "AddSportCarButton";
            this.AddSportCarButton.Size = new System.Drawing.Size(154, 28);
            this.AddSportCarButton.TabIndex = 25;
            this.AddSportCarButton.Text = "Добавить спортивное авто";
            this.AddSportCarButton.UseVisualStyleBackColor = true;
            this.AddSportCarButton.Click += new System.EventHandler(this.AddSportCarButton_Click);
            // 
            // SportCarslistBox
            // 
            this.SportCarslistBox.FormattingEnabled = true;
            this.SportCarslistBox.Location = new System.Drawing.Point(38, 423);
            this.SportCarslistBox.Name = "SportCarslistBox";
            this.SportCarslistBox.Size = new System.Drawing.Size(919, 199);
            this.SportCarslistBox.TabIndex = 26;
            // 
            // RemoveCarButton
            // 
            this.RemoveCarButton.Location = new System.Drawing.Point(43, 346);
            this.RemoveCarButton.Name = "RemoveCarButton";
            this.RemoveCarButton.Size = new System.Drawing.Size(141, 28);
            this.RemoveCarButton.TabIndex = 27;
            this.RemoveCarButton.Text = "Удалить простое авто";
            this.RemoveCarButton.UseVisualStyleBackColor = true;
            this.RemoveCarButton.Click += new System.EventHandler(this.RemoveCarButton_Click);
            // 
            // RemoveSportCarButton
            // 
            this.RemoveSportCarButton.Location = new System.Drawing.Point(257, 244);
            this.RemoveSportCarButton.Name = "RemoveSportCarButton";
            this.RemoveSportCarButton.Size = new System.Drawing.Size(154, 28);
            this.RemoveSportCarButton.TabIndex = 28;
            this.RemoveSportCarButton.Text = "Удалить спортивное авто";
            this.RemoveSportCarButton.UseVisualStyleBackColor = true;
            this.RemoveSportCarButton.Click += new System.EventHandler(this.RemoveSportCarButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1160, 673);
            this.Controls.Add(this.RemoveSportCarButton);
            this.Controls.Add(this.RemoveCarButton);
            this.Controls.Add(this.SportCarslistBox);
            this.Controls.Add(this.AddSportCarButton);
            this.Controls.Add(this.AddCarButton);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.PriceTextBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.YearTextBox);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.RashodTextBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.MileageTextBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.ModelTextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.BrandTextBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.CarslistBox);
            this.Name = "Form1";
            this.Text = "Автомобили";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ListBox CarslistBox;
        private System.Windows.Forms.TextBox RashodTextBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox MileageTextBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox ModelTextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox BrandTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox PriceTextBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox YearTextBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button AddCarButton;
        private System.Windows.Forms.Button AddSportCarButton;
        private System.Windows.Forms.ListBox SportCarslistBox;
        private System.Windows.Forms.Button RemoveCarButton;
        private System.Windows.Forms.Button RemoveSportCarButton;
    }
}

